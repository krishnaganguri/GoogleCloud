﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class Author
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }

        private HashSet<Book> books;

        public Author() : this("No LastName")
        {

        }

        public Author(string lastName) : this(lastName, "No FirstName")
        {

        }

        // Designated Constructor
        public Author(string lastName, string firstName)
        {
            this.LastName = lastName;
            this.FirstName = firstName;
            books = new HashSet<Book>();
        }

        public void addBook(Book book)
        {
            books.Add(book);
        }
    }
}
