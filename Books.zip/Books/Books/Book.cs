﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class Book
    {
        public string Title { get; set; }
        private Author _author;
        public Author Author { 
            get
            {
                return _author;
            }
            set
            {
                _author = value;
                if(_author != null)
                {
                    _author.addBook(this);
                }
            }

        }
        private Dictionary<string, Chapter> chapters;

        public Book() : this("No Title")
        {

        }

        public Book(string title) : this(title, null)
        {
            
        }

        // Designated Constructor
        public Book(string title, Author author)
        {
            this.Title = title;
            this.Author = author;
            chapters = new Dictionary<string, Chapter>();
        }

        public void addChapter(Chapter chapter)
        {
            chapters[chapter.Name] = chapter;
        }

        public Chapter chapter(string chapterName)
        {
            Chapter chapter = new Chapter();
            chapters.TryGetValue(chapterName, out chapter);
            return chapter;
        }

        override
        public string ToString()
        {
            string res = null;
            if(Author != null)
            {
                res = Title + " by " + Author.FullName;
            }
            return res;
        }
    }
}
