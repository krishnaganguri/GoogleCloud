﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace Books
{
    public class BooksCommand : Command
    {
        override
        public bool Undoable
        {  get
            {
                return false;
            }
        }
        public BooksCommand() : base("Books")
        {

        }

        override
        public void execute(Library bdb)
        {
            bdb.DisplayBooksList();
        }

        override
        public Command clone()
        {
            return new BooksCommand();
        }

        override
        public void undo(Library bdb)
        {

        }
    }
}
