﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Books
{
    public abstract class Command
    {
        public string Name { get; set; }
        protected List<string> parameters;
        public abstract bool Undoable { get; }

        public Command() : this("Command")
        {

        }

        // Designated Constructor
        public Command(string name)
        {
            Name = name;
            parameters = new List<string>();
        }

        public void addParameter(string parameter)
        {
            parameters.Add(parameter);
        }

        public void reset()
        {
            parameters.Clear();
        }

        override
        public string ToString()
        {
            string output = this.Name;
            foreach(string parameter in parameters)
            {
                output += " " + parameter;
            }
            return output;
        }

        public abstract void execute(Library cbdb);

        public abstract Command clone();

        public abstract void undo(Library bdb);

    }
}
