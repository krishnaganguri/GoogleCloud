﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace Books
{
    public class AuthorsCommand : Command
    {
        override
        public bool Undoable
        {  get
            {
                return false;
            }
        }
        public AuthorsCommand() : base("Authors")
        {

        }

        override
        public void execute(Library bdb)
        {
            bdb.DisplayAuthorsList();
        }

        override
        public Command clone()
        {
            return new AuthorsCommand();
        }

        override
        public void undo(Library bdb)
        {

        }
    }
}
