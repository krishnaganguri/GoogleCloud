using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class Library
    {
		
		private ArrayList authorList = new ArrayList();
        private ArrayList bookList = new ArrayList();
        Dictionary<string, Command> commands = new Dictionary<string, Command>();
        Queue<Command> commandQueue = new Queue<Command>();
        Stack<Command> commandStack = new Stack<Command>();
		
		public void run()
        {
            commands["Author"] = new AuthorCommand();
            commands["Book"] = new BookCommand();
            commands["Assign"] = new AssignCommand();
            commands["Authors"] = new AuthorsCommand();
            commands["Books"] = new BooksCommand();

            while(commandQueue.Count > 0)
            {
                commandQueue.Dequeue().execute(this);
            }
            Console.WriteLine("Welcome to the Catalog of Books.");
            string userInput = "";
            while (true)
            {
                Command command = null;
                Console.WriteLine("\nWhat do you want to do?");
                Console.WriteLine("\nEnter a command (Author, Book, Assign, Authors, Books, quit.)");
    
                userInput = Console.ReadLine();
                if(!userInput.Equals("quit"))
                {
                    command = Parse(userInput);
                    if (command != null)
                    {
                        if (command.Undoable)
                        {
                            commandStack.Push(command);
                        }
                        command.execute(this);
                    }
                    else
                    {
                        Console.WriteLine("\nCommand not found.");
                    }
                }
                else
                {
                    Console.WriteLine("\nThank you for using Library.");
                    Environment.Exit(0);
                }
                
                
            }
        }

        public Command Parse(string commandLine)
        {
            Command command = null;

            string[] tokens = commandLine.Split(" ", StringSplitOptions.None);
            commands.TryGetValue(tokens[0], out command);
            if (command != null)
            {
                command = command.clone();
                command.reset();
                for (int i = 1; i < tokens.Length; i++)
                {
                    command.addParameter(tokens[i]);
                }
            }

            return command;
        }
		
		public void CreateAuthor(string lastName, string firstName)
        {
            Author author = new Author(lastName, firstName);
            authorList.Add(author);
            
            Console.WriteLine("\nA New Author " + author.FullName + " is created");
        }

        public void CreateBook(string name)
        {
           Book book = new Book(name);
            bookList.Add(book);

            Console.WriteLine("\nA New Book " + name + " is created");
        }

        public void DisplayAuthorsList()
        {
            Console.WriteLine("\n Authors list \n");
            foreach (Author val in authorList)
                Console.WriteLine(val.LastName+" "+val.FirstName);
        }

        public void AssignAuthor(string lastName, string firstName, string bookTitle)
        {
            Author author = new Author(lastName, firstName);
            bool assigned = false;
            foreach (Book val in bookList)
            {
                if(val.Title.Equals(bookTitle))
                {
                    val.Author = author;
                    assigned = true;
                }

            }

            if (!assigned)
            {
                Book book = new Book(bookTitle);
                book.Author = author;
                bookList.Add(book);
            }
           
            Console.WriteLine("\nBook " + bookTitle + " is assigned to " + lastName + " "+ firstName);
        }

        public void DisplayBooksList()
        {
            Console.WriteLine("\n Books list \n");
            foreach (Book val in bookList)
                Console.WriteLine(val.ToString());
        }
    }
}
