﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class Chapter
    {
        public string Name { get; set; }
        public string Content { get; set; }

        public Chapter() : this("No Chapter Name")
        {

        }

        public Chapter(string chapterName) : this(chapterName, "No text")
        {

        }

        // Designated Constructor
        public Chapter(string chapterName, string content)
        {
            this.Name = chapterName;
            this.Content = content;
        }
    }
}
