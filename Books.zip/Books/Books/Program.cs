﻿using System;

namespace Books
{
    class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();
            library.run();
        }
    }
}
