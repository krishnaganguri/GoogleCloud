﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class AuthorCommand : Command
    {
        override
        public bool Undoable
        {
            get
            {
                return true;
            }
        }
        public AuthorCommand() : base("Author")
        {

        }

        override
        public void execute(Library bdb)
        {
            if(parameters.Count == 2)
            {
                bdb.CreateAuthor(parameters[0], parameters[1]);
            }else if(parameters.Count == 1)
			{
				bdb.CreateAuthor(parameters[0], "");	
			}
            else
            {
                Console.WriteLine("Wrong number of parameters for Author command.");
            }
        }

        override
        public Command clone()
        {
            Command command = new AuthorCommand();
            foreach (String parameter in parameters)
            {
                command.addParameter(parameter);
            }
            return command;
        }

        override
        public void undo(Library bdb)
        {
            
        }
    }
}
