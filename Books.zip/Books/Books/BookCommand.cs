﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class BookCommand : Command
    {
        override
        public bool Undoable
        {
            get
            {
                return true;
            }
        }
        public BookCommand() : base("Book")
        {

        }

        override
        public void execute(Library bdb)
        {
            if(parameters.Count == 1)
            {
                bdb.CreateBook(parameters[0]);
            }
            else
            {
                Console.WriteLine("Wrong number of parameters for Book command.");
            }
        }

        override
        public Command clone()
        {
            Command command = new BookCommand();
            foreach (String parameter in parameters)
            {
                command.addParameter(parameter);
            }
            return command;
        }

        override
        public void undo(Library bdb)
        {
            
        }
    }
}
