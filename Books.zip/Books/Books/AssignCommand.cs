﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Books
{
    public class AssignCommand : Command
    {
        override
        public bool Undoable
        {
            get
            {
                return true;
            }
        }
        public AssignCommand() : base("Assign")
        {

        }

        override
        public void execute(Library bdb)
        {
            if(parameters.Count == 3)
            {
                bdb.AssignAuthor(parameters[0], parameters[1], parameters[2]);
            }
            else
            {
                Console.WriteLine("Wrong number of parameters for Assign command");
            }
        }

        override
        public Command clone()
        {
            Command command = new AssignCommand();
            foreach(String parameter in parameters)
            {
                command.addParameter(parameter);
            }
            return command;
        }

        override
        public void undo(Library bdb)
        {
            
        }
    }
}
